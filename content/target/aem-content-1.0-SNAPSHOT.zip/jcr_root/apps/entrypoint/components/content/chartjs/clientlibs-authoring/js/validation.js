(function (document, $) {
    "use strict";



})(document, Granite.$);